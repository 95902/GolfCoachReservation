import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || (session.user.role !== 'ADMIN' && session.user.role !== 'COACH')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { weekNumber, startDate, endDate, timeSlots } = await request.json()
    
    // Validate input
    if (!weekNumber || !startDate || !endDate) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Check if schedule exists for this week
    const existingSchedule = await db.weeklySchedule.findUnique({
      where: { weekNumber },
      include: { scheduleSlots: true }
    })

    if (existingSchedule) {
      // Update existing schedule
      await db.weeklySchedule.update({
        where: { weekNumber },
        data: {
          startDate: new Date(startDate),
          endDate: new Date(endDate),
          scheduleSlots: {
            deleteMany: {}, // Remove all existing slots
            create: timeSlots.map((slot: any) => ({
              dayOfWeek: parseInt(slot.dayOfWeek),
              startTime: slot.startTime,
              endTime: slot.endTime
            }))
          }
        }
      })
    } else {
      // Create new schedule
      await db.weeklySchedule.create({
        data: {
          weekNumber,
          startDate: new Date(startDate),
          endDate: new Date(endDate),
          scheduleSlots: {
            create: timeSlots.map((slot: any) => ({
              dayOfWeek: parseInt(slot.dayOfWeek),
              startTime: slot.startTime,
              endTime: slot.endTime
            }))
          }
        }
      })
    }
    
    return NextResponse.json({ 
      message: 'Schedule saved successfully',
      weekNumber,
      startDate,
      endDate,
      timeSlots
    })
  } catch (error) {
    console.error('Error saving schedule:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || (session.user.role !== 'ADMIN' && session.user.role !== 'COACH')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const schedules = await db.weeklySchedule.findMany({
      include: {
        scheduleSlots: {
          orderBy: {
            dayOfWeek: 'asc'
          }
        }
      },
      orderBy: {
        weekNumber: 'asc'
      }
    })
    
    // Format the response to match the expected structure
    const formattedSchedules = schedules.map(schedule => ({
      weekNumber: schedule.weekNumber,
      startDate: schedule.startDate.toISOString().split('T')[0],
      endDate: schedule.endDate.toISOString().split('T')[0],
      timeSlots: schedule.scheduleSlots.map(slot => ({
        id: slot.id,
        dayOfWeek: slot.dayOfWeek.toString(),
        startTime: slot.startTime,
        endTime: slot.endTime
      }))
    }))
    
    // Ensure we have both week 1 and week 2
    const result = []
    for (let week = 1; week <= 2; week++) {
      const existing = formattedSchedules.find(s => s.weekNumber === week)
      if (existing) {
        result.push(existing)
      } else {
        result.push({
          weekNumber: week,
          startDate: '',
          endDate: '',
          timeSlots: []
        })
      }
    }
    
    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching schedules:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}